FATE_REALAUDIO-$(call FRAMECRC, RM, RA_144) += fate-ra3-144
fate-ra3-144: CMD = framecrc -i $(TARGET_SAMPLES)/realaudio/ra3.ra

#FATE_REALAUDIO-$(call DEMDEC, RM, RA_288) += fate-ra4-288
fate-ra4-288: CMD = pcm -i $(TARGET_SAMPLES)/realaudio/ra4_288.ra
fate-ra4-288: REF = $(SAMPLES)/realaudio/ra4_288.pcm
fate-ra4-288: CMP = oneoff

FATE_REALMEDIA_AUDIO-$(call PCM, RM, RA_144) += fate-ra-144
fate-ra-144: CMD = md5 -i $(TARGET_SAMPLES)/real/ra3_in_rm_file.rm -f s16le

FATE_REALMEDIA_AUDIO-$(call PCM, RM, RA_288, ARESAMPLE_FILTER) += fate-ra-288
fate-ra-288: CMD = pcm -i $(TARGET_SAMPLES)/real/ra_288.rm
fate-ra-288: CMP = oneoff
fate-ra-288: REF = $(SAMPLES)/real/ra_288.pcm
fate-ra-288: FUZZ = 2

FATE_REALMEDIA_AUDIO-$(call PCM, RM, COOK, ARESAMPLE_FILTER) += fate-ra-cook
fate-ra-cook: CMD = pcm -i $(TARGET_SAMPLES)/real/ra_cook.rm
fate-ra-cook: CMP = oneoff
fate-ra-cook: REF = $(SAMPLES)/real/ra_cook.pcm

FATE_REALMEDIA_VIDEO-$(call FRAMECRC, RM, RV20) += fate-rv20-1239
fate-rv20-1239: CMD = framecrc -flags +bitexact -idct simple -lowres 1 -i $(TARGET_SAMPLES)/real/G2_with_SVT_320_240.rm

FATE_REALMEDIA_VIDEO-$(call FRAMECRC, RM, RV30) += fate-rv30
fate-rv30: CMD = framecrc -flags +bitexact -idct simple -i $(TARGET_SAMPLES)/real/rv30.rm -an

FATE_REALMEDIA_VIDEO-$(call FRAMECRC, RM, RV40) += fate-rv40
fate-rv40: CMD = framecrc -i $(TARGET_SAMPLES)/real/spygames-2MB.rmvb -t 10 -an

FATE_SIPR += fate-sipr-5k0
fate-sipr-5k0: CMD = pcm -i $(TARGET_SAMPLES)/sipr/sipr_5k0.rm
fate-sipr-5k0: REF = $(SAMPLES)/sipr/sipr_5k0.pcm

FATE_SIPR += fate-sipr-6k5
fate-sipr-6k5: CMD = pcm -i $(TARGET_SAMPLES)/sipr/sipr_6k5.rm
fate-sipr-6k5: REF = $(SAMPLES)/sipr/sipr_6k5.pcm

FATE_SIPR += fate-sipr-8k5
fate-sipr-8k5: CMD = pcm -i $(TARGET_SAMPLES)/sipr/sipr_8k5.rm
fate-sipr-8k5: REF = $(SAMPLES)/sipr/sipr_8k5.pcm

FATE_SIPR += fate-sipr-16k
fate-sipr-16k: CMD = pcm -i $(TARGET_SAMPLES)/sipr/sipr_16k.rm -frames:a 3250
fate-sipr-16k: REF = $(SAMPLES)/sipr/sipr_16k.pcm
fate-sipr-16k: SIZE_TOLERANCE = 40000

$(FATE_SIPR): CMP = oneoff

FATE_REALMEDIA_AUDIO-$(call PCM, RM, SIPR, ARESAMPLE_FILTER) += $(FATE_SIPR)
fate-sipr: $(FATE_SIPR)

fate-realaudio: $(FATE_REALAUDIO-yes)
fate-realmedia-audio: $(FATE_REALMEDIA_AUDIO-yes)
fate-realmedia-video: $(FATE_REALMEDIA_VIDEO-yes)
fate-realmedia: fate-realmedia-audio fate-realmedia-video
fate-real: fate-realaudio fate-realmedia

FATE_SAMPLES_FFMPEG += $(FATE_REALAUDIO-yes) $(FATE_REALMEDIA_AUDIO-yes) $(FATE_REALMEDIA_VIDEO-yes)
