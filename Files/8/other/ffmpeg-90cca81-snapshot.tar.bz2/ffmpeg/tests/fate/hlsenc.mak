tests/data/live_no_endlist.m3u8: TAG = GEN
tests/data/live_no_endlist.m3u8: ffmpeg$(PROGSSUF)$(EXESUF) | tests/data
	$(M)$(TARGET_EXEC) $(TARGET_PATH)/$< -nostdin \
        -f lavfi -v verbose -i "aevalsrc=cos(2*PI*t)*sin(2*PI*(440+4*t)*t):d=20" -f hls -hls_time 3 -map 0 \
        -hls_flags omit_endlist -codec:a mp2fixed -hls_segment_filename $(TARGET_PATH)/tests/data/live_no_endlist_%03d.ts \
        $(TARGET_PATH)/tests/data/live_no_endlist.m3u8 2>/dev/null

FATE_HLSENC-$(call FILTERDEMDECENCMUX, HDCD AEVALSRC ARESAMPLE, HLS MPEGTS, MP2 PCM_F64LE, MP2FIXED PCM_S24LE, HLS MPEGTS PCM_S24LE, LAVFI_INDEV) += fate-hls-live-no-endlist
fate-hls-live-no-endlist: tests/data/live_no_endlist.m3u8
fate-hls-live-no-endlist: SRC = $(TARGET_PATH)/tests/data/live_no_endlist.m3u8
fate-hls-live-no-endlist: CMD = md5 -i $(SRC) -af hdcd=process_stereo=false -t 6 -f s24le
fate-hls-live-no-endlist: CMP = oneline
fate-hls-live-no-endlist: REF = e038bb8e65d4c1745b9b3ed643e607a3

tests/data/event_no_endlist.m3u8: TAG = GEN
tests/data/event_no_endlist.m3u8: ffmpeg$(PROGSSUF)$(EXESUF) | tests/data
	$(M)$(TARGET_EXEC) $(TARGET_PATH)/$< -nostdin \
        -f lavfi -v verbose -i "aevalsrc=cos(2*PI*t)*sin(2*PI*(440+4*t)*t):d=20" -f hls -hls_time 3 -map 0 \
        -hls_playlist_type event -hls_flags omit_endlist -hls_list_size 0 -codec:a mp2fixed \
        -hls_segment_filename $(TARGET_PATH)/tests/data/event_no_endlist_%03d.ts \
        $(TARGET_PATH)/tests/data/event_no_endlist.m3u8 2>/dev/null

FATE_HLSENC-$(call FILTERDEMDECENCMUX, HDCD AEVALSRC ARESAMPLE, HLS MPEGTS, MP2 PCM_F64LE, MP2FIXED PCM_S24LE, HLS MPEGTS PCM_S24LE, LAVFI_INDEV) += fate-hls-event-no-endlist
fate-hls-event-no-endlist: tests/data/event_no_endlist.m3u8
fate-hls-event-no-endlist: SRC = $(TARGET_PATH)/tests/data/event_no_endlist.m3u8
fate-hls-event-no-endlist: CMD = md5 -ss 3 -i $(SRC) -af hdcd=process_stereo=false -t 3 -f s24le
fate-hls-event-no-endlist: CMP = oneline
fate-hls-event-no-endlist: REF = d9cd56b6aaebf67a52a63dd44ec5b085

tests/data/live_last_endlist.m3u8: TAG = GEN
tests/data/live_last_endlist.m3u8: ffmpeg$(PROGSSUF)$(EXESUF) | tests/data
	$(M)$(TARGET_EXEC) $(TARGET_PATH)/$< -nostdin \
        -f lavfi -v verbose -i "aevalsrc=cos(2*PI*t)*sin(2*PI*(440+4*t)*t):d=20" -f hls -hls_time 3 -map 0 \
        -codec:a mp2fixed -hls_segment_filename $(TARGET_PATH)/tests/data/live_last_endlist_%03d.ts \
        $(TARGET_PATH)/tests/data/live_last_endlist.m3u8 2>/dev/null

FATE_HLSENC-$(call FILTERDEMDECENCMUX, HDCD AEVALSRC ARESAMPLE, HLS MPEGTS, MP2 PCM_F64LE, MP2FIXED PCM_S24LE, HLS MPEGTS PCM_S24LE, LAVFI_INDEV) += fate-hls-live-last-endlist
fate-hls-live-last-endlist: tests/data/live_last_endlist.m3u8
fate-hls-live-last-endlist: SRC = $(TARGET_PATH)/tests/data/live_last_endlist.m3u8
fate-hls-live-last-endlist: CMD = md5 -i $(SRC) -af hdcd=process_stereo=false -t 6 -f s24le
fate-hls-live-last-endlist: CMP = oneline
fate-hls-live-last-endlist: REF = 2ca8567092dcf01e37bedd50454d1ab7


tests/data/live_endlist.m3u8: TAG = GEN
tests/data/live_endlist.m3u8: ffmpeg$(PROGSSUF)$(EXESUF) | tests/data
	$(M)$(TARGET_EXEC) $(TARGET_PATH)/$< -nostdin \
        -f lavfi -i "aevalsrc=cos(2*PI*t)*sin(2*PI*(440+4*t)*t):d=20" -f hls -hls_time 3 -map 0 \
        -hls_list_size 0 -codec:a mp2fixed -hls_segment_filename $(TARGET_PATH)/tests/data/live_endlist_%d.ts \
        $(TARGET_PATH)/tests/data/live_endlist.m3u8 2>/dev/null

FATE_HLSENC-$(call FILTERDEMDECENCMUX, HDCD AEVALSRC ARESAMPLE, HLS MPEGTS, MP2 PCM_F64LE, MP2FIXED PCM_S24LE, HLS MPEGTS PCM_S24LE, LAVFI_INDEV ) += fate-hls-live-endlist
fate-hls-live-endlist: tests/data/live_endlist.m3u8
fate-hls-live-endlist: SRC = $(TARGET_PATH)/tests/data/live_endlist.m3u8
fate-hls-live-endlist: CMD = md5 -i $(SRC) -af hdcd=process_stereo=false -t 20 -f s24le
fate-hls-live-endlist: CMP = oneline
fate-hls-live-endlist: REF = e189ce781d9c87882f58e3929455167b

tests/data/hls_segment_size.m3u8: TAG = GEN
tests/data/hls_segment_size.m3u8: ffmpeg$(PROGSSUF)$(EXESUF) | tests/data
	$(M)$(TARGET_EXEC) $(TARGET_PATH)/$< -nostdin \
	-f lavfi -i "aevalsrc=cos(2*PI*t)*sin(2*PI*(440+4*t)*t):d=20" -f hls -hls_segment_size 300000 -map 0 \
	-hls_list_size 0 -codec:a mp2fixed -hls_segment_filename $(TARGET_PATH)/tests/data/hls_segment_size_%d.ts \
	$(TARGET_PATH)/tests/data/hls_segment_size.m3u8 2>/dev/null

FATE_HLSENC-$(call FILTERDEMDECENCMUX, AEVALSRC ARESAMPLE, HLS MPEGTS, MP2 PCM_F64LE, MP2FIXED, HLS MPEGTS, LAVFI_INDEV) += fate-hls-segment-size
fate-hls-segment-size: tests/data/hls_segment_size.m3u8
fate-hls-segment-size: CMD = framecrc -auto_conversion_filters -flags +bitexact -i $(TARGET_PATH)/tests/data/hls_segment_size.m3u8 -vf setpts=N*23

tests/data/hls_segment_single.m3u8: TAG = GEN
tests/data/hls_segment_single.m3u8: ffmpeg$(PROGSSUF)$(EXESUF) | tests/data
	$(M)$(TARGET_EXEC) $(TARGET_PATH)/$< -nostdin \
	-f lavfi -i "aevalsrc=cos(2*PI*t)*sin(2*PI*(440+4*t)*t):d=20" -f hls -hls_flags single_file -map 0 \
	-hls_list_size 0 -codec:a mp2fixed -hls_segment_filename $(TARGET_PATH)/tests/data/hls_segment_single.ts \
	$(TARGET_PATH)/tests/data/hls_segment_single.m3u8 2>/dev/null

FATE_HLSENC-$(call FILTERDEMDECENCMUX, AEVALSRC ARESAMPLE, HLS MPEGTS, MP2 PCM_F64LE, MP2FIXED, HLS MPEGTS, LAVFI_INDEV) += fate-hls-segment-single
fate-hls-segment-single: tests/data/hls_segment_single.m3u8
fate-hls-segment-single: CMD = framecrc -auto_conversion_filters -flags +bitexact -i $(TARGET_PATH)/tests/data/hls_segment_single.m3u8 -vf setpts=N*23

tests/data/hls_init_time.m3u8: TAG = GEN
tests/data/hls_init_time.m3u8: ffmpeg$(PROGSSUF)$(EXESUF) | tests/data
	$(M)$(TARGET_EXEC) $(TARGET_PATH)/$< -nostdin \
	-f lavfi -i "aevalsrc=cos(2*PI*t)*sin(2*PI*(440+4*t)*t):d=11" -f hls -hls_init_time 1 -hls_time 3 -map 0 \
	-hls_list_size 5 -codec:a mp2fixed -hls_segment_filename $(TARGET_PATH)/tests/data/hls_init_time_%d.ts \
	$(TARGET_PATH)/tests/data/hls_init_time.m3u8 2>/dev/null

FATE_HLSENC-$(call FILTERDEMDECENCMUX, AEVALSRC ARESAMPLE, HLS MPEGTS, MP2 PCM_F64LE, MP2FIXED, HLS MPEGTS, LAVFI_INDEV) += fate-hls-init-time
fate-hls-init-time: tests/data/hls_init_time.m3u8
fate-hls-init-time: CMD = framecrc -auto_conversion_filters -flags +bitexact -i $(TARGET_PATH)/tests/data/hls_init_time.m3u8 -vf setpts=N*23

tests/data/hls_list_size.m3u8: TAG = GEN
tests/data/hls_list_size.m3u8: ffmpeg$(PROGSSUF)$(EXESUF) | tests/data
	$(M)$(TARGET_EXEC) $(TARGET_PATH)/$< -nostdin \
	-f lavfi -i "aevalsrc=cos(2*PI*t)*sin(2*PI*(440+4*t)*t):d=20" -f hls -hls_time 4 -map 0 \
	-hls_list_size 4 -codec:a mp2fixed -hls_segment_filename $(TARGET_PATH)/tests/data/hls_list_size_%d.ts \
	$(TARGET_PATH)/tests/data/hls_list_size.m3u8 2>/dev/null

FATE_HLSENC-$(call FILTERDEMDECENCMUX, AEVALSRC ARESAMPLE, HLS MPEGTS, MP2 PCM_F64LE, MP2FIXED, HLS MPEGTS, LAVFI_INDEV) += fate-hls-list-size
fate-hls-list-size: tests/data/hls_list_size.m3u8
fate-hls-list-size: CMD = framecrc -auto_conversion_filters -flags +bitexact -i $(TARGET_PATH)/tests/data/hls_list_size.m3u8 -vf setpts=N*23

tests/data/hls_fmp4.m3u8: TAG = GEN
tests/data/hls_fmp4.m3u8: ffmpeg$(PROGSSUF)$(EXESUF) | tests/data
	$(M)$(TARGET_EXEC) $(TARGET_PATH)/$< -nostdin \
	-f lavfi -re -i "aevalsrc=cos(2*PI*t)*sin(2*PI*(440+4*t)*t):d=5" -map 0 -codec:a mp2fixed \
	-hls_segment_type mpegts -hls_fmp4_init_filename now.mp4 -hls_list_size 0 \
	-hls_time 1 -hls_segment_filename "$(TARGET_PATH)/tests/data/hls_fmp4_%d.m4s" \
	$(TARGET_PATH)/tests/data/hls_fmp4.m3u8 2>/dev/null

FATE_HLSENC-$(call FILTERDEMDECENCMUX, AEVALSRC ARESAMPLE, HLS MPEGTS, MP2 PCM_F64LE, MP2FIXED, HLS MPEGTS, LAVFI_INDEV) += fate-hls-fmp4
fate-hls-fmp4: tests/data/hls_fmp4.m3u8
fate-hls-fmp4: CMD = framecrc -auto_conversion_filters -flags +bitexact -i $(TARGET_PATH)/tests/data/hls_fmp4.m3u8 -vf setpts=N*23

tests/data/hls_fmp4_ac3.m3u8: TAG = GEN
tests/data/hls_fmp4_ac3.m3u8: ffmpeg$(PROGSSUF)$(EXESUF) | tests/data
	$(M)$(TARGET_EXEC) $(TARGET_PATH)/$< -nostdin \
	-stream_loop 4 -i $(TARGET_SAMPLES)/ac3/monsters_inc_5.1_448_small.ac3 -c copy -map 0 \
	-hls_segment_type fmp4 -hls_fmp4_init_filename now_ac3.mp4 -hls_list_size 0 \
	-hls_time 2 -hls_segment_filename "$(TARGET_PATH)/tests/data/hls_fmp4_ac3_%d.m4s" \
	$(TARGET_PATH)/tests/data/hls_fmp4_ac3.m3u8 2>/dev/null

FATE_HLSENC-yes := $(if $(call FRAMECRC), $(FATE_HLSENC-yes))

FATE_HLSENC_PROBE-$(call DEMMUX, HLS AC3, HLS MP4, AC3_DECODER) += fate-hls-fmp4_ac3
fate-hls-fmp4_ac3: tests/data/hls_fmp4_ac3.m3u8
fate-hls-fmp4_ac3: CMD = probeaudiostream $(TARGET_PATH)/tests/data/now_ac3.mp4


tests/data/hls_cmfa.m3u8: TAG = GEN
tests/data/hls_cmfa.m3u8: ffmpeg$(PROGSSUF)$(EXESUF) | tests/data
	$(M)$(TARGET_EXEC) $(TARGET_PATH)/$< -nostdin \
	-i $(TARGET_SAMPLES)/aac/al06_44.mp4 -c copy -map 0 \
	-hls_segment_type fmp4 -hls_fmp4_init_filename now.cmfa -hls_list_size 0 \
	-hls_time 1 -hls_segment_filename "$(TARGET_PATH)/tests/data/hls_fmp4_%d.cmfa" \
	-t 1 $(TARGET_PATH)/tests/data/hls_cmfa.m3u8 2>/dev/null

FATE_HLSENC-yes := $(if $(call FRAMECRC), $(FATE_HLSENC-yes))

FATE_HLSENC_PROBE-$(call FRAMECRC, HLS) += fate-hls-cmfa
fate-hls-cmfa: tests/data/hls_cmfa.m3u8
fate-hls-cmfa: CMD = framecrc -i $(TARGET_PATH)/tests/data/hls_cmfa.m3u8 -c copy

FATE_SAMPLES_FFMPEG += $(FATE_HLSENC-yes)
FATE_SAMPLES_FFMPEG_FFPROBE += $(FATE_HLSENC_PROBE-yes)

# -- Tests below do not require FATE samples (lavfi-generated input only) --

tests/data/hls_playlist_type_vod.m3u8: TAG = GEN
tests/data/hls_playlist_type_vod.m3u8: ffmpeg$(PROGSSUF)$(EXESUF) | tests/data
	$(M)$(TARGET_EXEC) $(TARGET_PATH)/$< -nostdin \
	-f lavfi -i "testsrc2=size=128x72:rate=1:d=3" -f hls -hls_time 1 -map 0:v \
	-hls_playlist_type vod -hls_list_size 0 -c:v mpeg2video -g 1 \
	-hls_segment_filename $(TARGET_PATH)/tests/data/hls_playlist_type_vod_%d.ts \
	$(TARGET_PATH)/tests/data/hls_playlist_type_vod.m3u8 2>/dev/null

FATE_HLSENC_LAVFI-$(call ALLYES, TESTSRC2_FILTER LAVFI_INDEV MPEG2VIDEO_ENCODER HLS_MUXER MPEGTS_MUXER FILE_PROTOCOL) += fate-hls-playlist-type-vod
fate-hls-playlist-type-vod: tests/data/hls_playlist_type_vod.m3u8
fate-hls-playlist-type-vod: CMD = sed -n -e /^\#EXT-X-PLAYLIST-TYPE:/p -e /^\#EXT-X-ENDLIST/p $(TARGET_PATH)/tests/data/hls_playlist_type_vod.m3u8
fate-hls-playlist-type-vod: CMP = diff

tests/data/hls_playlist_type_event.m3u8: TAG = GEN
tests/data/hls_playlist_type_event.m3u8: ffmpeg$(PROGSSUF)$(EXESUF) | tests/data
	$(M)$(TARGET_EXEC) $(TARGET_PATH)/$< -nostdin \
	-f lavfi -i "testsrc2=size=128x72:rate=1:d=3" -f hls -hls_time 1 -map 0:v \
	-hls_playlist_type event -hls_list_size 0 -c:v mpeg2video -g 1 \
	-hls_segment_filename $(TARGET_PATH)/tests/data/hls_playlist_type_event_%d.ts \
	$(TARGET_PATH)/tests/data/hls_playlist_type_event.m3u8 2>/dev/null

FATE_HLSENC_LAVFI-$(call ALLYES, TESTSRC2_FILTER LAVFI_INDEV MPEG2VIDEO_ENCODER HLS_MUXER MPEGTS_MUXER FILE_PROTOCOL) += fate-hls-playlist-type-event
fate-hls-playlist-type-event: tests/data/hls_playlist_type_event.m3u8
fate-hls-playlist-type-event: CMD = sed -n -e /^\#EXT-X-PLAYLIST-TYPE:/p -e /^\#EXT-X-ENDLIST/p $(TARGET_PATH)/tests/data/hls_playlist_type_event.m3u8
fate-hls-playlist-type-event: CMP = diff

tests/data/hls_round_durations.m3u8: TAG = GEN
tests/data/hls_round_durations.m3u8: ffmpeg$(PROGSSUF)$(EXESUF) | tests/data
	$(M)$(TARGET_EXEC) $(TARGET_PATH)/$< -nostdin \
	-f lavfi -i "testsrc2=size=128x72:rate=1:d=3" -f hls -hls_time 1 -map 0:v \
	-hls_flags round_durations -hls_list_size 0 -c:v mpeg2video -g 1 \
	-hls_segment_filename $(TARGET_PATH)/tests/data/hls_round_durations_%d.ts \
	$(TARGET_PATH)/tests/data/hls_round_durations.m3u8 2>/dev/null

FATE_HLSENC_LAVFI-$(call ALLYES, TESTSRC2_FILTER LAVFI_INDEV MPEG2VIDEO_ENCODER HLS_MUXER MPEGTS_MUXER FILE_PROTOCOL) += fate-hls-round-durations
fate-hls-round-durations: tests/data/hls_round_durations.m3u8
fate-hls-round-durations: CMD = sed -n -e /^\#EXTINF:/p $(TARGET_PATH)/tests/data/hls_round_durations.m3u8
fate-hls-round-durations: CMP = diff

tests/data/hls_discont_start.m3u8: TAG = GEN
tests/data/hls_discont_start.m3u8: ffmpeg$(PROGSSUF)$(EXESUF) | tests/data
	$(M)$(TARGET_EXEC) $(TARGET_PATH)/$< -nostdin \
	-f lavfi -i "testsrc2=size=128x72:rate=1:d=3" -f hls -hls_time 1 -map 0:v \
	-hls_flags discont_start -hls_list_size 0 -c:v mpeg2video -g 1 \
	-hls_segment_filename $(TARGET_PATH)/tests/data/hls_discont_start_%d.ts \
	$(TARGET_PATH)/tests/data/hls_discont_start.m3u8 2>/dev/null

FATE_HLSENC_LAVFI-$(call ALLYES, TESTSRC2_FILTER LAVFI_INDEV MPEG2VIDEO_ENCODER HLS_MUXER MPEGTS_MUXER FILE_PROTOCOL) += fate-hls-discont-start
fate-hls-discont-start: tests/data/hls_discont_start.m3u8
fate-hls-discont-start: CMD = sed -n -e /^\#EXT-X-DISCONTINUITY/p -e /^\#EXTINF:/p -e /^[^\#]/p $(TARGET_PATH)/tests/data/hls_discont_start.m3u8
fate-hls-discont-start: CMP = diff

tests/data/hls_independent_segments.m3u8: TAG = GEN
tests/data/hls_independent_segments.m3u8: ffmpeg$(PROGSSUF)$(EXESUF) | tests/data
	$(M)$(TARGET_EXEC) $(TARGET_PATH)/$< -nostdin \
	-f lavfi -i "testsrc2=size=128x72:rate=1:d=3" -f hls -hls_time 1 -map 0:v \
	-hls_flags independent_segments -hls_list_size 0 -c:v mpeg2video -g 1 \
	-hls_segment_filename $(TARGET_PATH)/tests/data/hls_independent_segments_%d.ts \
	$(TARGET_PATH)/tests/data/hls_independent_segments.m3u8 2>/dev/null

FATE_HLSENC_LAVFI-$(call ALLYES, TESTSRC2_FILTER LAVFI_INDEV MPEG2VIDEO_ENCODER HLS_MUXER MPEGTS_MUXER FILE_PROTOCOL) += fate-hls-independent-segments
fate-hls-independent-segments: tests/data/hls_independent_segments.m3u8
fate-hls-independent-segments: CMD = sed -n -e /^\#EXT-X-INDEPENDENT-SEGMENTS/p $(TARGET_PATH)/tests/data/hls_independent_segments.m3u8
fate-hls-independent-segments: CMP = diff

tests/data/hls_start_number.m3u8: TAG = GEN
tests/data/hls_start_number.m3u8: ffmpeg$(PROGSSUF)$(EXESUF) | tests/data
	$(M)$(TARGET_EXEC) $(TARGET_PATH)/$< -nostdin \
	-f lavfi -i "testsrc2=size=128x72:rate=1:d=3" -f hls -hls_time 1 -map 0:v \
	-start_number 100 -hls_list_size 0 -c:v mpeg2video -g 1 \
	-hls_segment_filename $(TARGET_PATH)/tests/data/hls_start_number_%d.ts \
	$(TARGET_PATH)/tests/data/hls_start_number.m3u8 2>/dev/null

FATE_HLSENC_LAVFI-$(call ALLYES, TESTSRC2_FILTER LAVFI_INDEV MPEG2VIDEO_ENCODER HLS_MUXER MPEGTS_MUXER FILE_PROTOCOL) += fate-hls-start-number
fate-hls-start-number: tests/data/hls_start_number.m3u8
fate-hls-start-number: CMD = sed -n -e /^\#EXT-X-MEDIA-SEQUENCE:/p -e /^[^\#]/p $(TARGET_PATH)/tests/data/hls_start_number.m3u8
fate-hls-start-number: CMP = diff

tests/data/hls_iframes_single_mpegts.m3u8: TAG = GEN
tests/data/hls_iframes_single_mpegts.m3u8: ffmpeg$(PROGSSUF)$(EXESUF) | tests/data
	$(M)$(TARGET_EXEC) $(TARGET_PATH)/$< -nostdin \
	-f lavfi -i "testsrc2=size=128x72:rate=1:d=3" -f hls -hls_time 1 -map 0:v \
	-hls_list_size 0 -c:v mpeg2video -g 1 -bitexact \
	-hls_segment_type mpegts -hls_flags iframes_only+single_file \
	-hls_segment_filename $(TARGET_PATH)/tests/data/hls_iframes_single_mpegts.ts \
	$(TARGET_PATH)/tests/data/hls_iframes_single_mpegts.m3u8 2>/dev/null

FATE_HLSENC_LAVFI-$(call ALLYES, TESTSRC2_FILTER LAVFI_INDEV MPEG2VIDEO_ENCODER HLS_MUXER MPEGTS_MUXER FILE_PROTOCOL) += fate-hls-iframes-single-mpegts
fate-hls-iframes-single-mpegts: tests/data/hls_iframes_single_mpegts.m3u8
fate-hls-iframes-single-mpegts: CMD = sed -n -e /^\#EXT-X-BYTERANGE:/p $(TARGET_PATH)/tests/data/hls_iframes_single_mpegts.m3u8
fate-hls-iframes-single-mpegts: CMP = diff

tests/data/hls_iframes_single_fmp4.m3u8: TAG = GEN
tests/data/hls_iframes_single_fmp4.m3u8: ffmpeg$(PROGSSUF)$(EXESUF) | tests/data
	$(M)$(TARGET_EXEC) $(TARGET_PATH)/$< -nostdin \
	-f lavfi -i "testsrc2=size=128x72:rate=1:d=3" -f hls -hls_time 1 -map 0:v \
	-hls_list_size 0 -c:v mpeg2video -g 1 -bitexact -dct int \
	-hls_segment_type fmp4 -hls_flags iframes_only+single_file \
	-hls_segment_filename $(TARGET_PATH)/tests/data/hls_iframes_single_fmp4.mp4 \
	$(TARGET_PATH)/tests/data/hls_iframes_single_fmp4.m3u8 2>/dev/null

FATE_HLSENC_LAVFI-$(call ALLYES, TESTSRC2_FILTER LAVFI_INDEV MPEG2VIDEO_ENCODER HLS_MUXER MOV_MUXER FILE_PROTOCOL) += fate-hls-iframes-single-fmp4
fate-hls-iframes-single-fmp4: tests/data/hls_iframes_single_fmp4.m3u8
fate-hls-iframes-single-fmp4: CMD = sed -n -e /^\#EXT-X-MAP:/p -e /^\#EXT-X-BYTERANGE:/p $(TARGET_PATH)/tests/data/hls_iframes_single_fmp4.m3u8
fate-hls-iframes-single-fmp4: CMP = diff

FATE_HLSENC_LAVFI-yes := $(if $(call FRAMECRC), $(FATE_HLSENC_LAVFI-yes))

FATE_FFMPEG += $(FATE_HLSENC_LAVFI-yes)
fate-hlsenc: $(FATE_HLSENC-yes) $(FATE_HLSENC_PROBE-yes) $(FATE_HLSENC_LAVFI-yes)
